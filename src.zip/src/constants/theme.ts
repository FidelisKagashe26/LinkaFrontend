// src/constants/theme.ts

// Key ya kuhifadhi theme mode kwenye localStorage
export const THEME_STORAGE_KEY = "app_theme_mode";
